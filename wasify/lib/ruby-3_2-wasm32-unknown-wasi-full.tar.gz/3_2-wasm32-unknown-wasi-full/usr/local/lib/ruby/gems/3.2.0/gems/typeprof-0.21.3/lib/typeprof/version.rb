module TypeProf
  VERSION = "0.21.3"
end
