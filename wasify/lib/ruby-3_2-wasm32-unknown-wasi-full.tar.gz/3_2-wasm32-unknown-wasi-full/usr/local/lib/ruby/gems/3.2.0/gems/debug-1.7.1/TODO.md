# TODO

## Basic functionality

* Support Fibers and Ractors

## UI

* Multi-line support
* Completion for Ruby's code
* Interactive breakpoint setting
* Interactive record & play debugging
* irb integration

## Debug command

* Watch points
    * Lightweight watchpoints for instance variables with Ruby 3.3 features (TP:ivar_set)
* Alias

## Debug port

* Debug port for monitoring
